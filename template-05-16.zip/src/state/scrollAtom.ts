import { atom } from "jotai";

export const postStickyScrollAtom = atom(0);

