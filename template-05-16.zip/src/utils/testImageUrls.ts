// Logs automáticos para debuggear URLs de imágenes

// Log automático cuando se carga el módulo
if (typeof window !== 'undefined') {
  console.log('🔧 Sistema de debug de imágenes de tokens iniciado');
  console.log('📋 Monitoreando carga de imágenes automáticamente...');
}
